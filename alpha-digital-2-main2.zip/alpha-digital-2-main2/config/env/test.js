'use strict';

module.exports = {
    env: 'test',
    mongo: {
        uri: 'mongodb://127.0.0.1:27017/pisignage-test'
    }
};