#install ffmpeg and image magic throough homebrew

#install ffmpeg 

brew install ffmpeg

#install imagemagic

brew install imagemagick